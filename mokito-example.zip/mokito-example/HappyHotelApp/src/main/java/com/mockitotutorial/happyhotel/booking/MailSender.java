package com.mockitotutorial.happyhotel.booking;

public class MailSender {

	public void sendBookingConfirmation(String bookingId) {
		// TODO Not done yet. John Smith to implement!
		throw new UnsupportedOperationException("Not implemented yet");
	}

}
