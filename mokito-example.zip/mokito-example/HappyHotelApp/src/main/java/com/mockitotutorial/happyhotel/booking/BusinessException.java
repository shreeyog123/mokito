package com.mockitotutorial.happyhotel.booking;

public class BusinessException extends RuntimeException {

}
