package com.mockitotutorial.happyhotel.booking;

import org.junit.jupiter.api.Test;

class Test00SanityCheck {

	@Test
	void test() {
		// should pass
	}

}
